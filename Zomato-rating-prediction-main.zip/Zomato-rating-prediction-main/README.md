# Zomato-rating-prediction
Using Flask framework , zomato restaurant rating prediction web app was created
